// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-dropdown',
//   templateUrl: './dropdown.component.html',
//   styleUrl: './dropdown.component.css'
// })
// export class DropdownComponent {

// }
import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent implements OnInit {

    showPopup: boolean = false;
  
   
  

  countries: string[] = [];
  states: string[] = [];
  cities: string[] = [];
  selectedCountry: string = '';
  selectedState: string = '';
  selectedCity: string = '';

  constructor(private dataService: DataService) {}

  ngOnInit() {
    this.countries = this.dataService.getCountries().map(c => c.name);
  }

  onCountryChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    const country = target.value;
    this.selectedCountry = country;
    this.states = this.dataService.getStates(country).map(s => s.name);
    this.selectedState = '';
    this.cities = [];
    this.selectedCity = '';
  }
  
  onStateChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    const state = target.value;
    this.selectedState = state;
    this.cities = this.dataService.getCities(this.selectedCountry, state);
    this.selectedCity = '';
  }
  
  onCityChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    const city = target.value;
    this.selectedCity = city;
    this.showPopup = true;
  }
 
}

