// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-popup-form',
//   templateUrl: './popup-form.component.html',
//   styleUrl: './popup-form.component.css'
// })
// export class PopupFormComponent {

// }


import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-popup-form',
  templateUrl: './popup-form.component.html',
  styleUrls: ['./popup-form.component.css']
})
export class PopupFormComponent {
  @Input() city: string = '';
  @Output() close = new EventEmitter<void>();

  onClose() {
    this.close.emit();
  }
}
