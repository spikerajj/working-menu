
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private countries = [
    {
      name: 'USA',
      states: [
        {
          name: 'California',
          cities: ['Los Angeles', 'San Francisco']
        },
        {
          name: 'New York',
          cities: ['New York City', 'Buffalo']
        }
      ]
    },
    {
      name: 'Canada',
      states: [
        {
          name: 'Ontario',
          cities: ['Toronto', 'Ottawa']
        },
        {
          name: 'Quebec',
          cities: ['Montreal', 'Quebec City']
        }
      ]
    }
  ];

  getCountries() {
    return this.countries;
  }

  getStates(countryName: string) {
    const country = this.countries.find(c => c.name === countryName);
    return country ? country.states : [];
  }

  getCities(countryName: string, stateName: string) {
    const state = this.getStates(countryName).find(s => s.name === stateName);
    return state ? state.cities : [];
  }
}

