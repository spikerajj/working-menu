
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-popup-form',
  templateUrl: './popup-form.component.html',
  styleUrls: ['./popup-form.component.css']
})
export class PopupFormComponent {
  @Input() city: string = '';
  @Output() close = new EventEmitter<void>();

  registrationForm: FormGroup;

    constructor(private fb: FormBuilder) {
      this.registrationForm = this.fb.group({
        name: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['', Validators.required],
        age: ['', Validators.required]
      }, { validator: this.passwordMatchValidator });
    }
  
    passwordMatchValidator(form: FormGroup) {
      const password = form.get('password');
      const confirmPassword = form.get('confirmPassword');
      if (password && confirmPassword && password.value !== confirmPassword.value) {
        confirmPassword.setErrors({ mismatch: true });
      } else {
        confirmPassword?.setErrors(null);
      }
    }
  
    onSubmit() {
      if (this.registrationForm.valid) {
        console.log(this.registrationForm.value);
      }
    }

  onClose() {
    this.close.emit();
  }
}





// import { Component } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';

// @Component({
//   selector: 'app-registration',
//   templateUrl: './registration.component.html',
//   styleUrls: ['./registration.component.css']
// })
// export class RegistrationComponent {
//   registrationForm: FormGroup;

//   constructor(private fb: FormBuilder) {
//     this.registrationForm = this.fb.group({
//       name: ['', Validators.required],
//       email: ['', [Validators.required, Validators.email]],
//       password: ['', [Validators.required, Validators.minLength(6)]],
//       confirmPassword: ['', Validators.required],
//       age: ['', Validators.required]
//     }, { validator: this.passwordMatchValidator });
//   }

//   passwordMatchValidator(form: FormGroup) {
//     const password = form.get('password');
//     const confirmPassword = form.get('confirmPassword');
//     if (password && confirmPassword && password.value !== confirmPassword.value) {
//       confirmPassword.setErrors({ mismatch: true });
//     } else {
//       confirmPassword?.setErrors(null);
//     }
//   }

//   onSubmit() {
//     if (this.registrationForm.valid) {
//       console.log(this.registrationForm.value);
//     }
//   }
// }

  