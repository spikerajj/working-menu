import { Pipe, PipeTransform } from '@angular/core';
import { Customer } from '../models/customer';

@Pipe({
  name: 'filter',
  standalone: true
})
export class FilterPipe implements PipeTransform {

  transform(inputs: Customer[], arg:string): Customer[]{
    if (arg== "") return inputs;
    else{
      return inputs.filter(m=>m.name.includes(arg) || m.address.includes(arg) )
    }
  }

}
