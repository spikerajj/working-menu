export interface Customer {
    id: number;
    name:string;
    address:string;
    cart: number;
    custPic:string
}
