import { CommonModule } from '@angular/common';
import { Component, numberAttribute, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Customer } from '../../models/customer';
import { FilterPipe } from '../../pipes/filter.pipe';
import { CustomerDetailComponent} from '../customer-detail/customer-detail.component';

@Component({
  selector: 'app-customerlist',
  standalone: true,
  imports: [CommonModule, CustomerDetailComponent, FormsModule, FilterPipe],
  templateUrl: './customerlist.component.html',
  styleUrl: './customerlist.component.css'
})
       //for Initializing the data
export class CustomerlistComponent implements OnInit {
  customerList:Customer[]=[];

  name: string=""
ngOnInit(): void {
  this.customerList.push({
    "id": 1,
    "name": "Raj",
    "address": "Wennam",
    "cart":4500,
    "custPic": "images/img1.jpg"
  });
  this.customerList.push( {
    "id": 2,
    "name": "Rakesh",
    "address": "Rohi",
    "cart":4500,
    "custPic": "images/img2.jpg"
  });
  this.customerList.push({
    "id": 3,
    "name": "Ramesh",
    "address": "DEonem",
    "cart":4500,
    "custPic": "images/img3.jpg"
  });
  this.customerList.push({
    "id": 4,
    "name": "Raat",
    "address": "Kennam",
    "cart":4500,
    "custPic": "images/img4.jpg"
  });
  this.customerList.push({
    "id": 5,
    "name": "Jese",
    "address": "Wrgfnam",
    "cart":4500,
    "custPic": "images/img5.jpg"
  });
}
onDataUpdated (customer:Customer){
const index=this.customerList.findIndex(m=>m.id == customer.id);
if(index<0){
  alert("No record found")}
    else{
      this.customerList.splice(index, 1, customer);
      alert("Data Updated");
    }
  }
    onDataDeleted(id:number){
      const index=this.customerList.findIndex(m=>m.id == id);
      if(index<0){
        alert("No record found")}
          else{
            this.customerList.splice(index, 1);
            alert("Data Deleted");
          }
    }
  }


