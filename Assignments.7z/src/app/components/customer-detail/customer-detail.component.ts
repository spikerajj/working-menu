import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Customer } from '../../models/customer';
import { FilterPipe } from '../../pipes/filter.pipe';
import { CustomerlistComponent } from '../customerlist/customerlist.component';

@Component({
  selector: 'app-customer-detail',
  standalone: true,
  imports: [CommonModule, FilterPipe, CustomerlistComponent, FormsModule],
  templateUrl: './customer-detail.component.html',
  styleUrl: './customer-detail.component.css'
})
export class CustomerDetailComponent {
  @Output() onUpdate : EventEmitter<Customer> = new EventEmitter<Customer>();
  @Output() onDelete : EventEmitter<number> = new EventEmitter<number>();
@Input() customer={} as Customer;

onCustomerUpdate(){
this.onUpdate.emit(this.customer);
}

onCustomerDelete(){
  this.onDelete.emit(this.customer.id);
  }

}
